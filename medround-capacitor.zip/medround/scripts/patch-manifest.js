// مجوزهای لازم برای اعلان دقیق و تکرارشونده را به AndroidManifest اضافه می‌کند
const fs = require('fs'), f = 'android/app/src/main/AndroidManifest.xml';
if (fs.existsSync(f)) {
  let s = fs.readFileSync(f, 'utf8');
  const perms = ['POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'RECEIVE_BOOT_COMPLETED', 'VIBRATE'];
  const add = perms.filter(p => !s.includes('android.permission.' + p + '"'))
    .map(p => `    <uses-permission android:name="android.permission.${p}" />\n`).join('');
  if (add) { s = s.replace('<application', add + '    <application'); fs.writeFileSync(f, s); }
  console.log('manifest ok');
}
