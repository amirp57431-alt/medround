// فونت وزیرمتن را از بسته‌ی npm داخل www/fonts کپی می‌کند تا برنامه آفلاین هم فونت داشته باشد
const fs = require('fs'), path = require('path');
function find(d) {
  for (const f of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, f.name);
    if (f.isDirectory()) { const r = find(p); if (r) return r; }
    else if (f.name === 'Vazirmatn[wght].woff2') return p;
  }
}
try {
  const src = find('node_modules/vazirmatn');
  fs.mkdirSync('www/fonts', { recursive: true });
  if (src) { fs.copyFileSync(src, 'www/fonts/Vazirmatn.woff2'); console.log('font ok'); }
  else console.log('font not found (برنامه با فونت پیش‌فرض گوشی کار می‌کند)');
} catch (e) { console.log('font skipped'); }
